﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Aula_07___Pilars
{
    internal class Program
    {
        static void Main(string[] args)
        {

            Veiculo v1 = new Veiculo();     //data de hoje
            Veiculo v2 = new Veiculo(new DateTime(2023, 10, 29));
            Console.WriteLine("V1:" + v1.ToString() + "Ano:" + v1.QualAno());

            Carro c1 = new Carro();
            Carro c2 = new Carro(COMBOS.Ele, "Opel");
            Carro c3 = new Carro(COMBOS.Ele, "Opel", new DateTime(2000, 12, 12));
            Carro c4 = new Carro(COMBOS.Gas, new DateTime(2020,10,12), "Renault");

            Console.WriteLine("C3:" + c3.ToString() + "Ano:" + c3.QualAno());


            //int x = int.Parse(12.ToString());

            //Carro c = new Carro();
            //c.ano = 2024;

            //Bike b = new Bike();

            ////b.anoB = 2023;

            //Veiculo v = new Veiculo();
            //v.anoV = 2000;

            //Console.WriteLine("Ano Bike:" + b.QualAno().ToString());

            //b.anoV = 2023;

            //Console.WriteLine("Ano Bike:" + b.QualAno().ToString());

        }
    }
}
