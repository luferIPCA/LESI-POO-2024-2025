﻿/*
*	<copyright file="Aula_07___Pilars.cs" company="IPCA">
*		Copyright (c) 2024 All Rights Reserved
*	</copyright>
* 	<author>mustl</author>
*   <date>10/28/2024 3:30:40 PM</date>
*	<description></description>
**/
using System;

namespace Aula_07___Pilars
{
    /// <summary>
    /// Purpose:
    /// Created by: mustl
    /// Created on: 10/28/2024 3:30:40 PM
    /// </summary>
    /// <remarks></remarks>
    /// <example></example>
    public class Carros
    {
        #region Attributes
        #endregion

        #region Methods

        #region Constructors

        /// <summary>
        /// The default Constructor.
        /// </summary>
        public Carros()
        {
        }

        #endregion

        #region Properties
        #endregion



        #region Overrides
        #endregion

        #region OtherMethods
        #endregion

        #region Destructor
        /// <summary>
        /// The destructor.
        /// </summary>
        ~Carros()
        {
        }
        #endregion

        #endregion
    }
}
